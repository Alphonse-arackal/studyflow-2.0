import { useLocation } from 'react-router-dom'
import { FiSearch, FiBell } from 'react-icons/fi'

import ThemeToggle from '../common/ThemeToggle'

const pageTitles = {
  '/': {
    title: 'Dashboard',
    subtitle: 'Your personal learning space.',
  },

  '/tasks': {
    title: 'My Tasks',
    subtitle: 'Plan your work and stay on track.',
  },

  '/notes': {
    title: 'My Notes',
    subtitle: 'Organize your knowledge in one place.',
  },

  '/revision': {
    title: 'Revision',
    subtitle: 'Review, practice, and remember more.',
  },

  '/calendar': {
    title: 'Calendar',
    subtitle: 'Plan your study schedule.',
  },
}

function Topbar() {
  const location = useLocation()

  const page = pageTitles[location.pathname] || {
    title: 'StudyFlow',
    subtitle: 'Your personal learning space.',
  }

  return (
    <header className="topbar">
      {/* Current page */}
      <div className="page-heading">
        <h1>{page.title}</h1>
        <p>{page.subtitle}</p>
      </div>

      {/* Actions */}
      <div className="topbar-actions">
        {/* Search */}
        <label className="search-box">
          <FiSearch size={18} />

          <input
            type="search"
            placeholder="Search anything..."
            aria-label="Search StudyFlow"
          />

          <span className="search-shortcut">/</span>
        </label>

        {/* Theme toggle */}
        <ThemeToggle />

        {/* Notifications */}
        <button
          type="button"
          className="icon-button notification-button"
          aria-label="Notifications"
          title="Notifications"
          onClick={() => alert('You have no new notifications.')}
        >
          <FiBell size={19} />
          <span className="notification-dot" />
        </button>

        {/* Profile avatar */}
        <div className="topbar-avatar" title="Student profile">
          S
        </div>
      </div>
    </header>
  )
}

export default Topbar