import { useEffect, useMemo, useState } from 'react'
import {
  FiCalendar, FiCheck, FiCheckSquare, FiCircle, FiClock, FiFileText,
  FiList, FiMoon, FiPlus, FiSettings, FiSun, FiTarget, FiBell,
  FiChevronDown, FiSearch, FiPlay, FiPause, FiRotateCcw, FiWatch,
} from 'react-icons/fi'

const starterTasks = [
  { id: 1, title: 'Complete DBMS assignment', description: 'Write the remaining questions and submit', dateOffset: 0, color: 'green', completed: true },
  { id: 2, title: 'Read Operating System notes', description: 'Chapter 3 - Process Management', dateOffset: 0, color: 'yellow', completed: false },
  { id: 3, title: 'Revise Java important questions', description: 'Focus on exception handling', dateOffset: 0, color: 'red', completed: false },
  { id: 4, title: 'Complete web development project', description: 'Work on the UI and fix responsiveness', dateOffset: 1, color: 'green', completed: false },
  { id: 5, title: 'Study for COA', description: 'Go through previous year questions', dateOffset: 1, color: 'yellow', completed: false },
  { id: 6, title: 'Make flashcards', description: 'Create flashcards for DBMS formulas', dateOffset: 1, color: 'gray', completed: false },
  { id: 7, title: 'Plan next week', description: 'Organize tasks and set goals', dateOffset: 2, color: 'green', completed: false },
]
const starterNotes = [
  'Read chapter 3 fully',
  'Important formulas for COA',
  'Complete project UI',
  'Buy chart paper',
  'Plan for next week',
]

function localDate(offset = 0) {
  const date = new Date()
  date.setDate(date.getDate() + offset)
  return date
}
function dateLabel(date) {
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

function Dashboard() {
  const [tasks, setTasks] = useState(starterTasks)
  const [notes, setNotes] = useState(starterNotes)
  const [noteDraft, setNoteDraft] = useState('')
  const [addingTask, setAddingTask] = useState(false)
  const [taskDraft, setTaskDraft] = useState('')
  const [mode, setMode] = useState('timer')
  const [seconds, setSeconds] = useState(11 * 60)
  const [running, setRunning] = useState(false)
  const [duration, setDuration] = useState(25)
  const [showTimerSettings, setShowTimerSettings] = useState(false)
  const [search, setSearch] = useState('')

  useEffect(() => {
    if (!running || mode === 'clock') return undefined
    const id = window.setInterval(() => setSeconds((value) => Math.max(0, value - 1)), 1000)
    return () => window.clearInterval(id)
  }, [running, mode])

  useEffect(() => {
    if (seconds === 0) setRunning(false)
  }, [seconds])

  const visibleTasks = useMemo(() => tasks.filter((task) => {
    const matchesSearch = `${task.title} ${task.description}`.toLowerCase().includes(search.toLowerCase())
    return task.dateOffset <= 2 && matchesSearch
  }), [tasks, search])
  const todayTasks = visibleTasks.filter((task) => task.dateOffset === 0)
  const completedToday = todayTasks.filter((task) => task.completed).length
  const progress = todayTasks.length ? Math.round((completedToday / todayTasks.length) * 100) : 0
  const timerDisplay = mode === 'clock'
    ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
    : `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`

  const addTask = (event) => {
    event.preventDefault()
    if (!taskDraft.trim()) return
    setTasks((current) => [...current, { id: Date.now(), title: taskDraft.trim(), description: 'Added to your study list', dateOffset: 0, color: 'green', completed: false }])
    setTaskDraft('')
    setAddingTask(false)
  }
  const addNote = (event) => {
    event.preventDefault()
    if (!noteDraft.trim()) return
    setNotes((current) => [...current, noteDraft.trim()])
    setNoteDraft('')
  }
  const chooseMode = (nextMode) => {
    setRunning(false)
    setMode(nextMode)
    if (nextMode === 'timer') setSeconds(duration * 60)
    if (nextMode === 'stopwatch') setSeconds(0)
  }
  const resetTimer = () => {
    setRunning(false)
    setSeconds(mode === 'stopwatch' ? 0 : duration * 60)
  }

  return (
    <div className="page dashboard-page reference-dashboard">
      <header className="reference-dashboard-heading">
        <div className="reference-title-wrap">
          <h2>Tasks <span>—</span> <time>{dateLabel(localDate())}</time></h2>
          <p>Keep your day clear, focused, and moving forward.</p>
        </div>
        <button className="primary-button reference-add-task" onClick={() => setAddingTask((value) => !value)} type="button">
          <FiPlus size={20} /> Add Task
        </button>
      </header>

      {addingTask && <form className="reference-inline-form" onSubmit={addTask}>
        <input autoFocus value={taskDraft} onChange={(event) => setTaskDraft(event.target.value)} placeholder="What do you need to do?" aria-label="New task title" />
        <button className="primary-button" type="submit">Save task</button>
        <button className="secondary-button" type="button" onClick={() => setAddingTask(false)}>Cancel</button>
      </form>}

      <div className="reference-dashboard-grid">
        <section className="reference-panel reference-tasks-panel">
          <div className="reference-panel-heading">
            <div className="reference-panel-title"><span className="reference-heading-icon"><FiList size={21} /></span><div><h3>My tasks</h3><p>Your upcoming study priorities</p></div></div>
            <span className="reference-count">{visibleTasks.length} tasks</span>
          </div>
          <div className="reference-task-list">
            {visibleTasks.map((task) => (
              <article className={`reference-task-row ${task.completed ? 'is-complete' : ''}`} key={task.id}>
                <span className={`reference-task-dot ${task.color}`} />
                <button className="reference-task-copy" type="button" onClick={() => setTasks((current) => current.map((item) => item.id === task.id ? { ...item, completed: !item.completed } : item))}>
                  <strong>{task.title}</strong><span>{task.description}</span>
                </button>
                <span className="reference-task-date"><FiCalendar size={16} />{dateLabel(localDate(task.dateOffset))}</span>
                <button className={`reference-task-check ${task.completed ? 'checked' : ''}`} aria-label={task.completed ? `Mark ${task.title} incomplete` : `Complete ${task.title}`} onClick={() => setTasks((current) => current.map((item) => item.id === task.id ? { ...item, completed: !item.completed } : item))} type="button">
                  {task.completed && <FiCheck size={17} />}
                </button>
              </article>
            ))}
            {visibleTasks.length === 0 && <div className="reference-empty">No matching tasks. Add one to get started.</div>}
          </div>
          <div className="reference-progress-card">
            <div className="reference-progress-heading"><strong>Today's tasks</strong><span><b>{progress}%</b> ({completedToday}/{todayTasks.length})</span></div>
            <div className="reference-progress-track"><span style={{ width: `${progress}%` }} /></div>
          </div>
        </section>

        <div className="reference-right-column">
          <section className="reference-panel reference-notes-panel">
            <div className="reference-panel-heading">
              <div className="reference-panel-title"><span className="reference-heading-icon"><FiFileText size={21} /></span><div><h3>Quick notes</h3><p>Little reminders for later</p></div></div>
              <button className="reference-square-button" type="button" aria-label="Add quick note" onClick={() => document.getElementById('reference-note-input')?.focus()}><FiPlus size={21} /></button>
            </div>
            <ul className="reference-notes-list">
              {notes.map((note, index) => <li key={`${note}-${index}`}><span className={`reference-note-dot note-${index % 3}`} />{note}</li>)}
            </ul>
            <form className="reference-note-form" onSubmit={addNote}>
              <span className="reference-note-dot note-muted" />
              <input id="reference-note-input" value={noteDraft} onChange={(event) => setNoteDraft(event.target.value)} placeholder="Add a quick note..." aria-label="Quick note" />
              {noteDraft.trim() && <button type="submit" aria-label="Save quick note"><FiCheck size={17} /></button>}
            </form>
          </section>

          <section className="reference-panel reference-timer-panel">
            <div className="reference-panel-heading">
              <div className="reference-panel-title"><span className="reference-heading-icon timer-heading-icon"><FiClock size={22} /></span><div><h3>Focus Timer</h3><p>Make time for what matters</p></div></div>
              <button className="reference-plain-icon" type="button" aria-label="Timer settings" onClick={() => setShowTimerSettings((value) => !value)}><FiSettings size={20} /></button>
            </div>
            {showTimerSettings && <form className="reference-timer-settings" onSubmit={(event) => { event.preventDefault(); setSeconds(duration * 60); setMode('timer'); setRunning(false); setShowTimerSettings(false) }}><label htmlFor="focus-duration">Focus duration (minutes)</label><input id="focus-duration" type="number" min="1" max="180" value={duration} onChange={(event) => setDuration(Math.max(1, Number(event.target.value) || 1))} /><button className="primary-button" type="submit">Apply</button></form>}
            <div className={`reference-timer-ring ${running ? 'is-running' : ''}`}><div className="reference-timer-inner"><span className="reference-timer-time">{timerDisplay}</span>{mode !== 'clock' && <span className="reference-timer-caption">{running ? 'STAY IN THE FLOW' : mode === 'stopwatch' ? 'STOPWATCH' : 'READY TO FOCUS'}</span>}</div></div>
            <div className="reference-timer-controls">
              <button className={mode === 'clock' ? 'active' : ''} onClick={() => chooseMode('clock')} type="button"><FiClock size={18} />Clock</button>
              <button className={mode === 'timer' ? 'active' : ''} onClick={() => chooseMode('timer')} type="button"><FiTarget size={18} />Timer</button>
              <button className={mode === 'stopwatch' ? 'active' : ''} onClick={() => chooseMode('stopwatch')} type="button"><FiWatch size={18} />Stopwatch</button>
            </div>
            {mode !== 'clock' && <div className="reference-timer-actions"><button className="primary-button" type="button" onClick={() => setRunning((value) => !value)}>{running ? <FiPause size={16} /> : <FiPlay size={16} />}{running ? 'Pause' : 'Start session'}</button><button className="secondary-button" type="button" onClick={resetTimer} aria-label="Reset timer"><FiRotateCcw size={16} />Reset</button></div>}
          </section>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
