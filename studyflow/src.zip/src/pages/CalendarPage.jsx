import { useMemo, useState } from 'react'
import {
  FiCalendar,
  FiChevronLeft,
  FiChevronRight,
  FiPlus,
  FiClock,
  FiMapPin,
  FiTrash2,
  FiBookOpen,
  FiCheckSquare,
  FiX,
} from 'react-icons/fi'

function getDateKey(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')

  return `${year}-${month}-${day}`
}

function formatSelectedDate(dateKey) {
  const date = new Date(`${dateKey}T12:00:00`)

  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  })
}

function CalendarPage() {
  const today = new Date()

  const [visibleMonth, setVisibleMonth] = useState(
    new Date(today.getFullYear(), today.getMonth(), 1),
  )

  const [selectedDate, setSelectedDate] = useState(getDateKey(today))

  const [events, setEvents] = useState([])
  const [timetableBlocks, setTimetableBlocks] = useState([])

  const [showEventForm, setShowEventForm] = useState(false)
  const [showTimetableForm, setShowTimetableForm] = useState(false)

  const [eventTitle, setEventTitle] = useState('')
  const [eventType, setEventType] = useState('Event')
  const [eventDescription, setEventDescription] = useState('')
  const [eventLocation, setEventLocation] = useState('')

  const [blockTitle, setBlockTitle] = useState('')
  const [blockStart, setBlockStart] = useState('09:00')
  const [blockEnd, setBlockEnd] = useState('10:00')
  const [blockType, setBlockType] = useState('Study')

  const monthName = visibleMonth.toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  })

  const daysInMonth = new Date(
    visibleMonth.getFullYear(),
    visibleMonth.getMonth() + 1,
    0,
  ).getDate()

  const firstWeekday = new Date(
    visibleMonth.getFullYear(),
    visibleMonth.getMonth(),
    1,
  ).getDay()

  const calendarDays = useMemo(() => {
    const days = []

    for (let i = 0; i < firstWeekday; i += 1) {
      days.push(null)
    }

    for (let day = 1; day <= daysInMonth; day += 1) {
      days.push(day)
    }

    return days
  }, [firstWeekday, daysInMonth])

  const selectedEvents = events.filter(
    (event) => event.date === selectedDate,
  )

  const selectedBlocks = timetableBlocks
    .filter((block) => block.date === selectedDate)
    .sort((a, b) => a.startTime.localeCompare(b.startTime))

  const monthHasItems = (day) => {
    if (!day) return false

    const dateKey = getDateKey(
      new Date(
        visibleMonth.getFullYear(),
        visibleMonth.getMonth(),
        day,
      ),
    )

    return (
      events.some((event) => event.date === dateKey) ||
      timetableBlocks.some((block) => block.date === dateKey)
    )
  }

  const changeMonth = (amount) => {
    setVisibleMonth(
      (previous) =>
        new Date(
          previous.getFullYear(),
          previous.getMonth() + amount,
          1,
        ),
    )
  }

  const selectDay = (day) => {
    if (!day) return

    const dateKey = getDateKey(
      new Date(
        visibleMonth.getFullYear(),
        visibleMonth.getMonth(),
        day,
      ),
    )

    setSelectedDate(dateKey)
  }

  const goToToday = () => {
    const now = new Date()

    setVisibleMonth(new Date(now.getFullYear(), now.getMonth(), 1))
    setSelectedDate(getDateKey(now))
  }

  const addEvent = (event) => {
    event.preventDefault()

    const title = eventTitle.trim()

    if (!title) return

    const newEvent = {
      id: crypto.randomUUID(),
      title,
      date: selectedDate,
      type: eventType,
      description: eventDescription.trim(),
      location: eventLocation.trim(),
    }

    setEvents((previous) => [...previous, newEvent])

    setEventTitle('')
    setEventDescription('')
    setEventLocation('')
    setEventType('Event')
    setShowEventForm(false)
  }

  const addTimetableBlock = (event) => {
    event.preventDefault()

    const title = blockTitle.trim()

    if (!title) return

    if (blockEnd <= blockStart) {
      alert('The end time must be later than the start time.')
      return
    }

    const newBlock = {
      id: crypto.randomUUID(),
      title,
      date: selectedDate,
      startTime: blockStart,
      endTime: blockEnd,
      type: blockType,
    }

    setTimetableBlocks((previous) => [...previous, newBlock])

    setBlockTitle('')
    setBlockStart('09:00')
    setBlockEnd('10:00')
    setBlockType('Study')
    setShowTimetableForm(false)
  }

  const deleteEvent = (eventId) => {
    setEvents((previous) =>
      previous.filter((event) => event.id !== eventId),
    )
  }

  const deleteTimetableBlock = (blockId) => {
    setTimetableBlocks((previous) =>
      previous.filter((block) => block.id !== blockId),
    )
  }

  const getEventClass = (type) => {
    return `event-type-${type.toLowerCase().replace(/\s+/g, '-')}`
  }

  return (
    <div className="page calendar-page">
      {/* Page introduction */}
      <section className="page-intro-card calendar-intro">
        <div>
          <span className="eyebrow">YOUR STUDY SCHEDULE</span>

          <h2>Make time for what matters.</h2>

          <p>
            Plan your schedule, track important dates, and organize
            your study sessions.
          </p>
        </div>

        <div className="calendar-intro-icon">
          <FiCalendar size={34} />
        </div>
      </section>

      {/* Main calendar layout */}
      <section className="calendar-workspace">
        {/* Monthly calendar */}
        <div className="content-card monthly-calendar">
          <div className="calendar-toolbar">
            <div>
              <h3>{monthName}</h3>
              <p>Choose a date to view its schedule.</p>
            </div>

            <div className="calendar-month-controls">
              <button
                type="button"
                className="icon-button"
                onClick={() => changeMonth(-1)}
                aria-label="Previous month"
                title="Previous month"
              >
                <FiChevronLeft />
              </button>

              <button
                type="button"
                className="icon-button"
                onClick={() => changeMonth(1)}
                aria-label="Next month"
                title="Next month"
              >
                <FiChevronRight />
              </button>
            </div>
          </div>

          <div className="calendar-legend">
            <span>
              <i className="legend-dot event-dot" />
              Events
            </span>

            <span>
              <i className="legend-dot timetable-dot" />
              Timetable
            </span>
          </div>

          <div className="calendar-grid">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(
              (day) => (
                <div className="calendar-weekday" key={day}>
                  {day}
                </div>
              ),
            )}

            {calendarDays.map((day, index) => {
              const dateKey = day
                ? getDateKey(
                    new Date(
                      visibleMonth.getFullYear(),
                      visibleMonth.getMonth(),
                      day,
                    ),
                  )
                : null

              const isToday = dateKey === getDateKey(new Date())
              const isSelected = dateKey === selectedDate
              const hasItems = monthHasItems(day)

              return (
                <button
                  key={`${day ?? 'empty'}-${index}`}
                  type="button"
                  disabled={!day}
                  className={[
                    'calendar-day',
                    !day ? 'empty-day' : '',
                    isToday ? 'today' : '',
                    isSelected ? 'selected' : '',
                  ]
                    .filter(Boolean)
                    .join(' ')}
                  onClick={() => selectDay(day)}
                  aria-label={
                    dateKey
                      ? `Select ${formatSelectedDate(dateKey)}`
                      : undefined
                  }
                  aria-pressed={isSelected}
                >
                  {day && (
                    <>
                      <span className="calendar-day-number">{day}</span>

                      {hasItems && (
                        <span className="calendar-day-indicator">
                          <i className="event-indicator" />
                          <i className="timetable-indicator" />
                        </span>
                      )}
                    </>
                  )}
                </button>
              )
            })}
          </div>

          <button
            type="button"
            className="today-button calendar-today-button"
            onClick={goToToday}
          >
            Go to today
          </button>
        </div>

        {/* Selected date details */}
        <div className="content-card selected-date-panel">
          <div className="selected-date-heading">
            <div>
              <span className="eyebrow">SELECTED DATE</span>

              <h3>{formatSelectedDate(selectedDate)}</h3>
            </div>
          </div>

          <div className="calendar-add-actions">
            <button
              type="button"
              className="primary-button"
              onClick={() => {
                setShowEventForm((previous) => !previous)
                setShowTimetableForm(false)
              }}
            >
              <FiPlus size={16} />
              Add event
            </button>

            <button
              type="button"
              className="secondary-button"
              onClick={() => {
                setShowTimetableForm((previous) => !previous)
                setShowEventForm(false)
              }}
            >
              <FiPlus size={16} />
              Add timetable
            </button>
          </div>

          {/* Event form */}
          {showEventForm && (
            <form className="calendar-form" onSubmit={addEvent}>
              <div className="calendar-form-heading">
                <h4>New event</h4>

                <button
                  type="button"
                  className="small-icon-button"
                  onClick={() => setShowEventForm(false)}
                  aria-label="Close event form"
                >
                  <FiX size={16} />
                </button>
              </div>

              <label>
                Event title
                <input
                  type="text"
                  value={eventTitle}
                  onChange={(event) => setEventTitle(event.target.value)}
                  placeholder="e.g. Semester examination"
                  required
                />
              </label>

              <label>
                Event type
                <select
                  value={eventType}
                  onChange={(event) => setEventType(event.target.value)}
                >
                  <option>Event</option>
                  <option>Exam</option>
                  <option>Deadline</option>
                  <option>Meeting</option>
                  <option>Personal</option>
                </select>
              </label>

              <label>
                Location (optional)
                <input
                  type="text"
                  value={eventLocation}
                  onChange={(event) => setEventLocation(event.target.value)}
                  placeholder="Enter location"
                />
              </label>

              <label>
                Description (optional)
                <textarea
                  value={eventDescription}
                  onChange={(event) =>
                    setEventDescription(event.target.value)
                  }
                  placeholder="Add details..."
                  rows={2}
                />
              </label>

              <button type="submit" className="primary-button">
                Save event
              </button>
            </form>
          )}

          {/* Timetable form */}
          {showTimetableForm && (
            <form
              className="calendar-form"
              onSubmit={addTimetableBlock}
            >
              <div className="calendar-form-heading">
                <h4>New timetable block</h4>

                <button
                  type="button"
                  className="small-icon-button"
                  onClick={() => setShowTimetableForm(false)}
                  aria-label="Close timetable form"
                >
                  <FiX size={16} />
                </button>
              </div>

              <label>
                Activity title
                <input
                  type="text"
                  value={blockTitle}
                  onChange={(event) => setBlockTitle(event.target.value)}
                  placeholder="e.g. Database revision"
                  required
                />
              </label>

              <label>
                Activity type
                <select
                  value={blockType}
                  onChange={(event) => setBlockType(event.target.value)}
                >
                  <option>Study</option>
                  <option>Class</option>
                  <option>Break</option>
                  <option>Personal</option>
                </select>
              </label>

              <div className="calendar-time-fields">
                <label>
                  Start time
                  <input
                    type="time"
                    value={blockStart}
                    onChange={(event) => setBlockStart(event.target.value)}
                    required
                  />
                </label>

                <label>
                  End time
                  <input
                    type="time"
                    value={blockEnd}
                    onChange={(event) => setBlockEnd(event.target.value)}
                    required
                  />
                </label>
              </div>

              <button type="submit" className="primary-button">
                Save timetable
              </button>
            </form>
          )}

          {/* Events list */}
          <div className="calendar-detail-section">
            <div className="calendar-detail-title">
              <FiCalendar size={17} />

              <h4>Events</h4>

              <span>{selectedEvents.length}</span>
            </div>

            {selectedEvents.length === 0 ? (
              <div className="calendar-empty-state">
                <p>No events scheduled for this date.</p>
              </div>
            ) : (
              <div className="calendar-item-list">
                {selectedEvents.map((event) => (
                  <article
                    className="calendar-event-item"
                    key={event.id}
                  >
                    <div className="calendar-event-color" />

                    <div className="calendar-item-content">
                      <span
                        className={`event-type-badge ${getEventClass(
                          event.type,
                        )}`}
                      >
                        {event.type}
                      </span>

                      <h5>{event.title}</h5>

                      {event.location && (
                        <p>
                          <FiMapPin size={13} />
                          {event.location}
                        </p>
                      )}

                      {event.description && (
                        <p className="calendar-item-description">
                          {event.description}
                        </p>
                      )}
                    </div>

                    <button
                      type="button"
                      className="task-delete-button"
                      onClick={() => deleteEvent(event.id)}
                      aria-label={`Delete event ${event.title}`}
                    >
                      <FiTrash2 size={15} />
                    </button>
                  </article>
                ))}
              </div>
            )}
          </div>

          {/* Timetable list */}
          <div className="calendar-detail-section">
            <div className="calendar-detail-title">
              <FiClock size={17} />

              <h4>Timetable</h4>

              <span>{selectedBlocks.length}</span>
            </div>

            {selectedBlocks.length === 0 ? (
              <div className="calendar-empty-state">
                <p>No timetable blocks scheduled for this date.</p>
              </div>
            ) : (
              <div className="calendar-item-list">
                {selectedBlocks.map((block) => (
                  <article
                    className="timetable-item"
                    key={block.id}
                  >
                    <div className="timetable-time">
                      <strong>{block.startTime}</strong>
                      <span>{block.endTime}</span>
                    </div>

                    <div className="timetable-item-content">
                      <h5>{block.title}</h5>
                      <span>{block.type}</span>
                    </div>

                    <button
                      type="button"
                      className="task-delete-button"
                      onClick={() => deleteTimetableBlock(block.id)}
                      aria-label={`Delete timetable block ${block.title}`}
                    >
                      <FiTrash2 size={15} />
                    </button>
                  </article>
                ))}
              </div>
            )}
          </div>

          {/* Tasks integration placeholder */}
          <div className="calendar-task-note">
            <FiCheckSquare size={17} />

            <div>
              <strong>Scheduled tasks</strong>

              <p>
                Date-specific tasks will appear here when the Tasks
                page is connected to the shared data store.
              </p>
            </div>
          </div>

          <div className="calendar-subject-note">
            <FiBookOpen size={16} />

            <span>
              Events and timetable blocks are stored as separate types.
            </span>
          </div>
        </div>
      </section>
    </div>
  )
}

export default CalendarPage