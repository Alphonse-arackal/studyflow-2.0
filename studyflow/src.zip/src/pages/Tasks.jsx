import { useState } from 'react'
import {
  FiCalendar,
  FiPlus,
  FiCheckCircle,
  FiCircle,
  FiRepeat,
  FiChevronLeft,
  FiChevronRight,
  FiList,
} from 'react-icons/fi'

function getLocalDateString(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')

  return `${year}-${month}-${day}`
}

function Tasks() {
  const [selectedDate, setSelectedDate] = useState(
    getLocalDateString(new Date()),
  )

  const [dailyTasks, setDailyTasks] = useState([])
  const [commonTasks, setCommonTasks] = useState([])

  const [newDailyTask, setNewDailyTask] = useState('')
  const [newCommonTask, setNewCommonTask] = useState('')

  // Completion is stored separately for each date.
  // A common task completed today can be incomplete tomorrow.
  const [commonCompletion, setCommonCompletion] = useState({})

  const dateObject = new Date(`${selectedDate}T12:00:00`)

  const formattedDate = dateObject.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  })

  const changeDate = (amount) => {
    const nextDate = new Date(`${selectedDate}T12:00:00`)
    nextDate.setDate(nextDate.getDate() + amount)
    setSelectedDate(getLocalDateString(nextDate))
  }

  const addDailyTask = (event) => {
    event.preventDefault()

    const title = newDailyTask.trim()
    if (!title) return

    setDailyTasks((previous) => [
      ...previous,
      {
        id: crypto.randomUUID(),
        title,
        date: selectedDate,
        completed: false,
      },
    ])

    setNewDailyTask('')
  }

  const addCommonTask = (event) => {
    event.preventDefault()

    const title = newCommonTask.trim()
    if (!title) return

    setCommonTasks((previous) => [
      ...previous,
      {
        id: crypto.randomUUID(),
        title,
      },
    ])

    setNewCommonTask('')
  }

  const toggleDailyTask = (taskId) => {
    setDailyTasks((previous) =>
      previous.map((task) =>
        task.id === taskId
          ? { ...task, completed: !task.completed }
          : task,
      ),
    )
  }

  const toggleCommonTask = (taskId) => {
    const completionKey = `${selectedDate}_${taskId}`

    setCommonCompletion((previous) => ({
      ...previous,
      [completionKey]: !previous[completionKey],
    }))
  }

  const deleteDailyTask = (taskId) => {
    setDailyTasks((previous) =>
      previous.filter((task) => task.id !== taskId),
    )
  }

  const deleteCommonTask = (taskId) => {
    setCommonTasks((previous) =>
      previous.filter((task) => task.id !== taskId),
    )

    setCommonCompletion((previous) => {
      const updated = { ...previous }

      Object.keys(updated).forEach((key) => {
        if (key.endsWith(`_${taskId}`)) {
          delete updated[key]
        }
      })

      return updated
    })
  }

  const visibleDailyTasks = dailyTasks.filter(
    (task) => task.date === selectedDate,
  )

  const completedDailyTasks = visibleDailyTasks.filter(
    (task) => task.completed,
  ).length

  const completedCommonTasks = commonTasks.filter(
    (task) => commonCompletion[`${selectedDate}_${task.id}`],
  ).length

  return (
    <div className="page tasks-page">
      {/* Page introduction */}
      <section className="page-intro-card">
        <span className="eyebrow">PLAN YOUR DAY</span>

        <h2>One task at a time.</h2>

        <p>
          Organize your daily priorities and build consistent study habits.
        </p>
      </section>

      {/* Date selector */}
      <section className="task-date-bar">
        <div className="task-date-info">
          <div className="task-date-icon">
            <FiCalendar size={21} />
          </div>

          <div>
            <span className="task-date-label">SELECTED DATE</span>
            <h3>{formattedDate}</h3>
          </div>
        </div>

        <div className="date-controls">
          <button
            type="button"
            className="icon-button"
            onClick={() => changeDate(-1)}
            aria-label="Previous day"
            title="Previous day"
          >
            <FiChevronLeft />
          </button>

          <input
            type="date"
            value={selectedDate}
            onChange={(event) => setSelectedDate(event.target.value)}
            aria-label="Select task date"
          />

          <button
            type="button"
            className="icon-button"
            onClick={() => changeDate(1)}
            aria-label="Next day"
            title="Next day"
          >
            <FiChevronRight />
          </button>

          <button
            type="button"
            className="today-button"
            onClick={() => setSelectedDate(getLocalDateString(new Date()))}
          >
            Today
          </button>
        </div>
      </section>

      {/* Task columns */}
      <section className="tasks-grid">
        {/* Date-specific tasks */}
        <article className="content-card task-section">
          <div className="task-section-heading">
            <div className="task-heading-icon daily-task-icon">
              <FiList size={20} />
            </div>

            <div className="task-heading-text">
              <h3>Daily tasks</h3>
              <p>Tasks for the selected date</p>
            </div>

            <span className="task-count">
              {completedDailyTasks}/{visibleDailyTasks.length}
            </span>
          </div>

          <div className="task-progress-track">
            <div
              className="task-progress-fill"
              style={{
                width: `${
                  visibleDailyTasks.length
                    ? (completedDailyTasks / visibleDailyTasks.length) * 100
                    : 0
                }%`,
              }}
            />
          </div>

          <form className="task-add-form" onSubmit={addDailyTask}>
            <input
              type="text"
              value={newDailyTask}
              onChange={(event) => setNewDailyTask(event.target.value)}
              placeholder="Add a task for this date..."
              aria-label="New daily task"
            />

            <button
              type="submit"
              className="primary-button task-add-button"
              aria-label="Add daily task"
            >
              <FiPlus size={17} />
              Add
            </button>
          </form>

          <div className="task-list">
            {visibleDailyTasks.length === 0 ? (
              <div className="task-empty-state">
                <FiCheckCircle size={27} />

                <h4>No tasks for this date</h4>

                <p>Add a task above to plan your day.</p>
              </div>
            ) : (
              visibleDailyTasks.map((task) => (
                <div
                  className={`task-item ${
                    task.completed ? 'completed' : ''
                  }`}
                  key={task.id}
                >
                  <button
                    type="button"
                    className="task-check"
                    onClick={() => toggleDailyTask(task.id)}
                    aria-label={
                      task.completed
                        ? `Mark ${task.title} incomplete`
                        : `Complete ${task.title}`
                    }
                  >
                    {task.completed ? (
                      <FiCheckCircle size={20} />
                    ) : (
                      <FiCircle size={20} />
                    )}
                  </button>

                  <span className="task-title">{task.title}</span>

                  <button
                    type="button"
                    className="task-delete-button"
                    onClick={() => deleteDailyTask(task.id)}
                    aria-label={`Delete ${task.title}`}
                    title="Delete task"
                  >
                    ×
                  </button>
                </div>
              ))
            )}
          </div>
        </article>

        {/* Common tasks */}
        <article className="content-card task-section">
          <div className="task-section-heading">
            <div className="task-heading-icon common-task-icon">
              <FiRepeat size={20} />
            </div>

            <div className="task-heading-text">
              <h3>Common tasks</h3>
              <p>Reusable tasks available every day</p>
            </div>

            <span className="task-count">
              {completedCommonTasks}/{commonTasks.length}
            </span>
          </div>

          <div className="common-task-notice">
            Completion is tracked separately for each date.
          </div>

          <form className="task-add-form" onSubmit={addCommonTask}>
            <input
              type="text"
              value={newCommonTask}
              onChange={(event) => setNewCommonTask(event.target.value)}
              placeholder="Add a recurring task..."
              aria-label="New common task"
            />

            <button
              type="submit"
              className="primary-button task-add-button"
              aria-label="Add common task"
            >
              <FiPlus size={17} />
              Add
            </button>
          </form>

          <div className="task-list">
            {commonTasks.length === 0 ? (
              <div className="task-empty-state">
                <FiRepeat size={27} />

                <h4>No common tasks yet</h4>

                <p>
                  Add routines such as reading, revision, or daily practice.
                </p>
              </div>
            ) : (
              commonTasks.map((task) => {
                const completionKey = `${selectedDate}_${task.id}`
                const completed = Boolean(commonCompletion[completionKey])

                return (
                  <div
                    className={`task-item ${
                      completed ? 'completed' : ''
                    }`}
                    key={task.id}
                  >
                    <button
                      type="button"
                      className="task-check"
                      onClick={() => toggleCommonTask(task.id)}
                      aria-label={
                        completed
                          ? `Mark ${task.title} incomplete`
                          : `Complete ${task.title}`
                      }
                    >
                      {completed ? (
                        <FiCheckCircle size={20} />
                      ) : (
                        <FiCircle size={20} />
                      )}
                    </button>

                    <span className="task-title">{task.title}</span>

                    <button
                      type="button"
                      className="task-delete-button"
                      onClick={() => deleteCommonTask(task.id)}
                      aria-label={`Delete ${task.title}`}
                      title="Delete task"
                    >
                      ×
                    </button>
                  </div>
                )
              })
            )}
          </div>
        </article>
      </section>
    </div>
  )
}

export default Tasks