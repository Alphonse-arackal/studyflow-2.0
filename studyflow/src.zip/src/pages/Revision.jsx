import { useMemo, useState } from 'react'
import {
  FiLayers,
  FiPlus,
  FiChevronLeft,
  FiChevronRight,
  FiCheckCircle,
  FiHelpCircle,
  FiBookOpen,
  FiTarget,
  FiTrash2,
  FiRotateCcw,
  FiEye,
  FiFileText,
} from 'react-icons/fi'

function Revision() {
  const [subjects, setSubjects] = useState([
    { id: 'subject-1', name: 'Computer Science' },
    { id: 'subject-2', name: 'Database Management' },
  ])

  const [selectedSubject, setSelectedSubject] = useState('subject-1')

  const [flashcards, setFlashcards] = useState([])
  const [mockTests, setMockTests] = useState([])

  const [questionInput, setQuestionInput] = useState('')
  const [answerInput, setAnswerInput] = useState('')
  const [subjectInput, setSubjectInput] = useState('')
  const [testTitleInput, setTestTitleInput] = useState('')

  const [showSubjectForm, setShowSubjectForm] = useState(false)
  const [showCardForm, setShowCardForm] = useState(false)
  const [showTestForm, setShowTestForm] = useState(false)

  const [activeCardIndex, setActiveCardIndex] = useState(0)
  const [showAnswer, setShowAnswer] = useState(false)

  // Store review history by flashcard ID.
  const [reviewStatus, setReviewStatus] = useState({})

  const currentSubject = subjects.find(
    (subject) => subject.id === selectedSubject,
  )

  const subjectCards = useMemo(
    () =>
      flashcards.filter(
        (card) => card.subjectId === selectedSubject,
      ),
    [flashcards, selectedSubject],
  )

  const subjectTests = mockTests.filter(
    (test) => test.subjectId === selectedSubject,
  )

  const activeCard = subjectCards[activeCardIndex]

  const knownCount = subjectCards.filter(
    (card) => reviewStatus[card.id] === 'known',
  ).length

  const unsureCount = subjectCards.filter(
    (card) => reviewStatus[card.id] === 'unsure',
  ).length

  const reviewedCount = knownCount + unsureCount

  const reviewPercentage = subjectCards.length
    ? Math.round((reviewedCount / subjectCards.length) * 100)
    : 0

  const addSubject = (event) => {
    event.preventDefault()

    const name = subjectInput.trim()

    if (!name) return

    const subject = {
      id: crypto.randomUUID(),
      name,
    }

    setSubjects((previous) => [...previous, subject])
    setSelectedSubject(subject.id)

    setSubjectInput('')
    setShowSubjectForm(false)
    setActiveCardIndex(0)
    setShowAnswer(false)
  }

  const addFlashcard = (event) => {
    event.preventDefault()

    const question = questionInput.trim()
    const answer = answerInput.trim()

    if (!question || !answer || !selectedSubject) return

    const card = {
      id: crypto.randomUUID(),
      subjectId: selectedSubject,
      question,
      answer,
      createdAt: new Date().toISOString(),
    }

    setFlashcards((previous) => [...previous, card])

    setQuestionInput('')
    setAnswerInput('')
    setShowCardForm(false)
    setActiveCardIndex(subjectCards.length)
    setShowAnswer(false)
  }

  const deleteFlashcard = (cardId) => {
    setFlashcards((previous) =>
      previous.filter((card) => card.id !== cardId),
    )

    setReviewStatus((previous) => {
      const updated = { ...previous }
      delete updated[cardId]
      return updated
    })

    setActiveCardIndex((previous) =>
      Math.max(0, Math.min(previous, subjectCards.length - 2)),
    )

    setShowAnswer(false)
  }

  const changeSubject = (subjectId) => {
    setSelectedSubject(subjectId)
    setActiveCardIndex(0)
    setShowAnswer(false)
    setShowCardForm(false)
    setShowTestForm(false)
  }

  const changeCard = (direction) => {
    if (!subjectCards.length) return

    setActiveCardIndex((previous) => {
      const next = previous + direction

      if (next < 0) return subjectCards.length - 1
      if (next >= subjectCards.length) return 0

      return next
    })

    setShowAnswer(false)
  }

  const markCard = (status) => {
    if (!activeCard) return

    setReviewStatus((previous) => ({
      ...previous,
      [activeCard.id]: status,
    }))

    setShowAnswer(false)

    if (activeCardIndex < subjectCards.length - 1) {
      setActiveCardIndex((previous) => previous + 1)
    }
  }

  const resetProgress = () => {
    const confirmed = window.confirm(
      'Reset the review progress for this subject?',
    )

    if (!confirmed) return

    setReviewStatus((previous) => {
      const updated = { ...previous }

      subjectCards.forEach((card) => {
        delete updated[card.id]
      })

      return updated
    })

    setActiveCardIndex(0)
    setShowAnswer(false)
  }

  const addMockTest = (event) => {
    event.preventDefault()

    const title = testTitleInput.trim()

    if (!title || !selectedSubject) return

    const test = {
      id: crypto.randomUUID(),
      subjectId: selectedSubject,
      title,
      createdAt: new Date().toISOString(),
    }

    setMockTests((previous) => [...previous, test])

    setTestTitleInput('')
    setShowTestForm(false)
  }

  const deleteMockTest = (testId) => {
    setMockTests((previous) =>
      previous.filter((test) => test.id !== testId),
    )
  }

  return (
    <div className="page revision-page">
      {/* Introduction */}
      <section className="page-intro-card revision-intro">
        <div>
          <span className="eyebrow">ACTIVE RECALL</span>

          <h2>Learn it. Test it. Remember it.</h2>

          <p>
            Strengthen your memory with flashcards and organize your
            practice tests by subject.
          </p>
        </div>

        <div className="revision-intro-icon">
          <FiLayers size={35} />
        </div>
      </section>

      {/* Subject selector */}
      <section className="content-card revision-subject-panel">
        <div className="revision-section-heading">
          <div>
            <h3>Your subjects</h3>
            <p>Choose a subject to review its flashcards and tests.</p>
          </div>

          <button
            type="button"
            className="primary-button"
            onClick={() => setShowSubjectForm((previous) => !previous)}
          >
            <FiPlus size={17} />
            Add subject
          </button>
        </div>

        {showSubjectForm && (
          <form className="revision-add-form" onSubmit={addSubject}>
            <input
              type="text"
              value={subjectInput}
              onChange={(event) => setSubjectInput(event.target.value)}
              placeholder="Enter subject name..."
              aria-label="New subject name"
              autoFocus
            />

            <button type="submit" className="primary-button">
              Create
            </button>
          </form>
        )}

        <div className="revision-subject-list">
          {subjects.map((subject) => {
            const count = flashcards.filter(
              (card) => card.subjectId === subject.id,
            ).length

            return (
              <button
                key={subject.id}
                type="button"
                className={`revision-subject-chip ${
                  selectedSubject === subject.id ? 'active' : ''
                }`}
                onClick={() => changeSubject(subject.id)}
              >
                <FiBookOpen size={17} />

                <span>{subject.name}</span>

                <span className="subject-card-count">{count}</span>
              </button>
            )
          })}
        </div>
      </section>

      {/* Progress cards */}
      <section className="revision-stats-grid">
        <article className="content-card revision-stat-card">
          <div className="revision-stat-icon">
            <FiLayers size={19} />
          </div>

          <span>Total flashcards</span>
          <h3>{subjectCards.length}</h3>
          <p>In {currentSubject?.name || 'this subject'}</p>
        </article>

        <article className="content-card revision-stat-card">
          <div className="revision-stat-icon known-stat-icon">
            <FiCheckCircle size={19} />
          </div>

          <span>Know it</span>
          <h3>{knownCount}</h3>
          <p>Cards marked as known</p>
        </article>

        <article className="content-card revision-stat-card">
          <div className="revision-stat-icon unsure-stat-icon">
            <FiHelpCircle size={19} />
          </div>

          <span>Needs revision</span>
          <h3>{unsureCount}</h3>
          <p>Cards marked not sure</p>
        </article>
      </section>

      {/* Flashcards */}
      <section className="content-card flashcard-section">
        <div className="revision-section-heading">
          <div>
            <span className="eyebrow">FLASHCARD PRACTICE</span>
            <h3>Test your memory</h3>
            <p>Try to answer before revealing the explanation.</p>
          </div>

          <button
            type="button"
            className="primary-button"
            onClick={() => setShowCardForm((previous) => !previous)}
            disabled={!selectedSubject}
          >
            <FiPlus size={17} />
            Create card
          </button>
        </div>

        {showCardForm && (
          <form className="flashcard-create-form" onSubmit={addFlashcard}>
            <label>
              Question
              <textarea
                value={questionInput}
                onChange={(event) => setQuestionInput(event.target.value)}
                placeholder="Enter the question..."
                rows={3}
                required
              />
            </label>

            <label>
              Answer
              <textarea
                value={answerInput}
                onChange={(event) => setAnswerInput(event.target.value)}
                placeholder="Enter the answer..."
                rows={4}
                required
              />
            </label>

            <div className="form-actions">
              <button
                type="button"
                className="secondary-button"
                onClick={() => setShowCardForm(false)}
              >
                Cancel
              </button>

              <button type="submit" className="primary-button">
                Save flashcard
              </button>
            </div>
          </form>
        )}

        {subjectCards.length === 0 ? (
          <div className="revision-empty-state">
            <div className="revision-empty-icon">
              <FiLayers size={28} />
            </div>

            <h4>No flashcards yet</h4>

            <p>
              Create your first flashcard for{' '}
              {currentSubject?.name || 'this subject'}.
            </p>

            <button
              type="button"
              className="primary-button"
              onClick={() => setShowCardForm(true)}
              disabled={!selectedSubject}
            >
              <FiPlus size={17} />
              Create your first card
            </button>
          </div>
        ) : (
          <>
            <div className="flashcard-navigation">
              <span>
                Card {activeCardIndex + 1} of {subjectCards.length}
              </span>

              <div className="flashcard-nav-buttons">
                <button
                  type="button"
                  className="icon-button"
                  onClick={() => changeCard(-1)}
                  aria-label="Previous flashcard"
                  title="Previous card"
                >
                  <FiChevronLeft />
                </button>

                <button
                  type="button"
                  className="icon-button"
                  onClick={() => changeCard(1)}
                  aria-label="Next flashcard"
                  title="Next card"
                >
                  <FiChevronRight />
                </button>
              </div>
            </div>

            <div className="flashcard">
              <div className="flashcard-topline">
                <span>QUESTION</span>

                {reviewStatus[activeCard.id] && (
                  <span
                    className={`review-status-badge ${
                      reviewStatus[activeCard.id]
                    }`}
                  >
                    {reviewStatus[activeCard.id] === 'known'
                      ? 'Know it'
                      : 'Needs revision'}
                  </span>
                )}
              </div>

              <h4>{activeCard.question}</h4>

              {showAnswer ? (
                <div className="flashcard-answer">
                  <span>ANSWER</span>
                  <p>{activeCard.answer}</p>
                </div>
              ) : (
                <button
                  type="button"
                  className="reveal-answer-button"
                  onClick={() => setShowAnswer(true)}
                >
                  <FiEye size={17} />
                  Reveal answer
                </button>
              )}
            </div>

            {showAnswer && (
              <div className="flashcard-review-actions">
                <button
                  type="button"
                  className="review-action unsure-action"
                  onClick={() => markCard('unsure')}
                >
                  <FiHelpCircle size={18} />
                  Not sure
                </button>

                <button
                  type="button"
                  className="review-action known-action"
                  onClick={() => markCard('known')}
                >
                  <FiCheckCircle size={18} />
                  Know it
                </button>
              </div>
            )}

            <div className="revision-progress-section">
              <div className="revision-progress-heading">
                <span>Review progress</span>
                <strong>{reviewPercentage}%</strong>
              </div>

              <div className="task-progress-track">
                <div
                  className="task-progress-fill"
                  style={{ width: `${reviewPercentage}%` }}
                />
              </div>

              <div className="revision-progress-footer">
                <span>{reviewedCount} reviewed</span>

                <button
                  type="button"
                  className="text-button"
                  onClick={resetProgress}
                >
                  <FiRotateCcw size={14} />
                  Reset progress
                </button>
              </div>
            </div>

            <div className="flashcard-management">
              <span>
                Reviewing{' '}
                <strong>{currentSubject?.name || 'subject'}</strong>
              </span>

              <button
                type="button"
                className="editor-delete-button"
                onClick={() => deleteFlashcard(activeCard.id)}
              >
                <FiTrash2 size={15} />
                Delete card
              </button>
            </div>
          </>
        )}
      </section>

      {/* Mock tests */}
      <section className="content-card mock-tests-section">
        <div className="revision-section-heading">
          <div>
            <span className="eyebrow">PRACTICE & ASSESSMENT</span>
            <h3>Mock tests</h3>
            <p>Keep your practice tests organized by subject.</p>
          </div>

          <button
            type="button"
            className="primary-button"
            onClick={() => setShowTestForm((previous) => !previous)}
            disabled={!selectedSubject}
          >
            <FiPlus size={17} />
            Add test
          </button>
        </div>

        {showTestForm && (
          <form className="revision-add-form" onSubmit={addMockTest}>
            <input
              type="text"
              value={testTitleInput}
              onChange={(event) => setTestTitleInput(event.target.value)}
              placeholder="Enter mock test title..."
              aria-label="Mock test title"
              required
            />

            <button type="submit" className="primary-button">
              Add test
            </button>
          </form>
        )}

        <div className="mock-test-list">
          {subjectTests.length === 0 ? (
            <div className="revision-empty-state compact">
              <div className="revision-empty-icon">
                <FiFileText size={25} />
              </div>

              <h4>No mock tests added</h4>

              <p>
                Add a test title to organize your practice sessions.
              </p>
            </div>
          ) : (
            subjectTests.map((test) => (
              <div className="mock-test-item" key={test.id}>
                <div className="mock-test-icon">
                  <FiFileText size={20} />
                </div>

                <div className="mock-test-details">
                  <strong>{test.title}</strong>
                  <span>{currentSubject?.name}</span>
                </div>

                <span className="mock-test-status">Planned</span>

                <button
                  type="button"
                  className="task-delete-button"
                  aria-label={`Delete ${test.title}`}
                  onClick={() => deleteMockTest(test.id)}
                >
                  ×
                </button>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  )
}

export default Revision