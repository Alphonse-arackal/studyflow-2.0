import { useState } from 'react'
import {
  FiBookOpen,
  FiPlus,
  FiSearch,
  FiFileText,
  FiTrash2,
  FiClock,
  FiEdit3,
  FiFolder,
} from 'react-icons/fi'

function Notes() {
  const [subjects, setSubjects] = useState([
    { id: 'subject-1', name: 'Computer Science' },
    { id: 'subject-2', name: 'Database Management' },
    { id: 'subject-3', name: 'Web Development' },
  ])

  const [notes, setNotes] = useState([])

  const [selectedSubject, setSelectedSubject] = useState('subject-1')
  const [selectedNote, setSelectedNote] = useState(null)

  const [subjectInput, setSubjectInput] = useState('')
  const [searchQuery, setSearchQuery] = useState('')

  const [isAddingSubject, setIsAddingSubject] = useState(false)
  const [isCreatingNote, setIsCreatingNote] = useState(false)

  const [editorTitle, setEditorTitle] = useState('')
  const [editorContent, setEditorContent] = useState('')

  const currentSubject = subjects.find(
    (subject) => subject.id === selectedSubject,
  )

  const subjectNotes = notes.filter(
    (note) => note.subjectId === selectedSubject,
  )

  const filteredNotes = subjectNotes.filter((note) =>
    note.title.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const createSubject = (event) => {
    event.preventDefault()

    const name = subjectInput.trim()

    if (!name) return

    const subject = {
      id: crypto.randomUUID(),
      name,
    }

    setSubjects((previous) => [...previous, subject])
    setSelectedSubject(subject.id)
    setSubjectInput('')
    setIsAddingSubject(false)
    setSelectedNote(null)
    setIsCreatingNote(false)
    setSearchQuery('')
  }

  const deleteSubject = (subjectId) => {
    const confirmed = window.confirm(
      'Delete this subject and all its notes?',
    )

    if (!confirmed) return

    setSubjects((previous) =>
      previous.filter((subject) => subject.id !== subjectId),
    )

    setNotes((previous) =>
      previous.filter((note) => note.subjectId !== subjectId),
    )

    if (selectedSubject === subjectId) {
      setSelectedSubject('')
      setSelectedNote(null)
      setIsCreatingNote(false)
      setEditorTitle('')
      setEditorContent('')
    }
  }

  const openNote = (note) => {
    setSelectedNote(note.id)
    setEditorTitle(note.title)
    setEditorContent(note.content)
    setIsCreatingNote(false)
  }

  const startNewNote = () => {
    if (!selectedSubject) {
      alert('Create or select a subject first.')
      return
    }

    setSelectedNote(null)
    setEditorTitle('')
    setEditorContent('')
    setIsCreatingNote(true)
  }

  const saveNote = () => {
    if (!selectedSubject) {
      alert('Select a subject first.')
      return
    }

    const title = editorTitle.trim()

    if (!title) {
      alert('Please enter a title for your note.')
      return
    }

    const now = new Date().toISOString()

    if (isCreatingNote) {
      const newNote = {
        id: crypto.randomUUID(),
        subjectId: selectedSubject,
        title,
        content: editorContent,
        updatedAt: now,
      }

      setNotes((previous) => [...previous, newNote])
      setSelectedNote(newNote.id)
      setIsCreatingNote(false)
    } else if (selectedNote) {
      setNotes((previous) =>
        previous.map((note) =>
          note.id === selectedNote
            ? {
                ...note,
                title,
                content: editorContent,
                updatedAt: now,
              }
            : note,
        ),
      )
    }
  }

  const deleteNote = (noteId) => {
    const confirmed = window.confirm('Delete this note?')

    if (!confirmed) return

    setNotes((previous) =>
      previous.filter((note) => note.id !== noteId),
    )

    if (selectedNote === noteId) {
      setSelectedNote(null)
      setEditorTitle('')
      setEditorContent('')
      setIsCreatingNote(false)
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return ''

    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    })
  }

  return (
    <div className="page notes-page">
      {/* Page heading */}
      <section className="page-intro-card notes-intro">
        <div>
          <span className="eyebrow">YOUR KNOWLEDGE LIBRARY</span>

          <h2>Think. Write. Remember.</h2>

          <p>
            Organize your subjects, capture important concepts, and
            build your personal study library.
          </p>
        </div>

        <button
          type="button"
          className="primary-button"
          onClick={startNewNote}
          disabled={!selectedSubject}
        >
          <FiPlus size={17} />
          New note
        </button>
      </section>

      {/* Three-column notes workspace */}
      <section className="notes-workspace">
        {/* Subjects panel */}
        <aside className="notes-sidebar content-card">
          <div className="notes-panel-heading">
            <div>
              <h3>Subjects</h3>
              <p>{subjects.length} subjects</p>
            </div>

            <button
              type="button"
              className="small-icon-button"
              aria-label="Add subject"
              title="Add subject"
              onClick={() => setIsAddingSubject((previous) => !previous)}
            >
              <FiPlus size={18} />
            </button>
          </div>

          {isAddingSubject && (
            <form
              className="subject-add-form"
              onSubmit={createSubject}
            >
              <input
                type="text"
                value={subjectInput}
                onChange={(event) => setSubjectInput(event.target.value)}
                placeholder="Subject name..."
                aria-label="New subject name"
                autoFocus
              />

              <button type="submit" className="primary-button">
                Add
              </button>
            </form>
          )}

          <div className="subject-list">
            {subjects.length === 0 ? (
              <div className="notes-mini-empty">
                <FiFolder size={22} />
                <p>No subjects yet.</p>
              </div>
            ) : (
              subjects.map((subject) => (
                <div
                  className={`subject-item ${
                    selectedSubject === subject.id ? 'active' : ''
                  }`}
                  key={subject.id}
                >
                  <button
                    type="button"
                    className="subject-select"
                    onClick={() => {
                      setSelectedSubject(subject.id)
                      setSelectedNote(null)
                      setIsCreatingNote(false)
                      setEditorTitle('')
                      setEditorContent('')
                      setSearchQuery('')
                    }}
                  >
                    <FiFolder size={17} />
                    <span>{subject.name}</span>
                  </button>

                  <button
                    type="button"
                    className="subject-delete-button"
                    aria-label={`Delete ${subject.name}`}
                    title={`Delete ${subject.name}`}
                    onClick={() => deleteSubject(subject.id)}
                  >
                    <FiTrash2 size={14} />
                  </button>
                </div>
              ))
            )}
          </div>

          <div className="notes-sidebar-footer">
            <FiBookOpen size={16} />
            <span>Your personal study library</span>
          </div>
        </aside>

        {/* Notes list */}
        <section className="notes-list-panel content-card">
          <div className="notes-panel-heading">
            <div>
              <h3>My notes</h3>
              <p>{currentSubject?.name || 'Select a subject'}</p>
            </div>

            <button
              type="button"
              className="small-icon-button"
              aria-label="Create note"
              title="Create note"
              onClick={startNewNote}
              disabled={!selectedSubject}
            >
              <FiPlus size={18} />
            </button>
          </div>

          <label className="notes-search">
            <FiSearch size={16} />

            <input
              type="search"
              placeholder="Find a note..."
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              aria-label="Search notes"
            />
          </label>

          <div className="notes-list">
            {!selectedSubject ? (
              <div className="notes-mini-empty">
                <FiFolder size={23} />
                <p>Select a subject to see its notes.</p>
              </div>
            ) : filteredNotes.length === 0 ? (
              <div className="notes-mini-empty">
                <FiFileText size={23} />

                <p>
                  {searchQuery
                    ? 'No matching notes found.'
                    : 'No notes in this subject yet.'}
                </p>
              </div>
            ) : (
              filteredNotes.map((note) => (
                <button
                  type="button"
                  key={note.id}
                  className={`note-list-item ${
                    selectedNote === note.id ? 'active' : ''
                  }`}
                  onClick={() => openNote(note)}
                >
                  <div className="note-list-icon">
                    <FiFileText size={17} />
                  </div>

                  <div className="note-list-details">
                    <strong>{note.title}</strong>

                    <span>
                      {note.content.trim()
                        ? `${note.content.trim().slice(0, 55)}${
                            note.content.trim().length > 55 ? '…' : ''
                          }`
                        : 'No content yet'}
                    </span>

                    <small>{formatDate(note.updatedAt)}</small>
                  </div>
                </button>
              ))
            )}
          </div>
        </section>

        {/* Note editor */}
        <section className="note-editor-panel content-card">
          {isCreatingNote || selectedNote ? (
            <>
              <div className="editor-toolbar">
                <div className="editor-status">
                  <FiEdit3 size={16} />
                  <span>
                    {isCreatingNote ? 'New note' : 'Note editor'}
                  </span>
                </div>

                {selectedNote && (
                  <button
                    type="button"
                    className="editor-delete-button"
                    onClick={() => deleteNote(selectedNote)}
                    title="Delete note"
                  >
                    <FiTrash2 size={16} />
                    <span>Delete</span>
                  </button>
                )}
              </div>

              <input
                type="text"
                className="note-title-input"
                placeholder="Give your note a title..."
                value={editorTitle}
                onChange={(event) => setEditorTitle(event.target.value)}
                aria-label="Note title"
              />

              <div className="editor-metadata">
                <FiFolder size={14} />
                <span>{currentSubject?.name || 'No subject'}</span>
              </div>

              <textarea
                className="note-content-input"
                placeholder={
                  'Start writing your notes here...\n\n' +
                  'Capture important concepts, definitions, examples, ' +
                  'and anything you want to remember.'
                }
                value={editorContent}
                onChange={(event) => setEditorContent(event.target.value)}
                aria-label="Note content"
              />

              <div className="editor-footer">
                <span>
                  <FiClock size={14} />
                  {editorContent.length} characters
                </span>

                <button
                  type="button"
                  className="primary-button"
                  onClick={saveNote}
                >
                  Save note
                </button>
              </div>
            </>
          ) : (
            <div className="note-editor-empty">
              <div className="note-editor-empty-icon">
                <FiFileText size={30} />
              </div>

              <h3>Select a note to begin</h3>

              <p>
                Choose a note from the list or create a new one
                to start writing.
              </p>

              <button
                type="button"
                className="primary-button"
                onClick={startNewNote}
                disabled={!selectedSubject}
              >
                <FiPlus size={17} />
                Create a note
              </button>
            </div>
          )}
        </section>
      </section>
    </div>
  )
}

export default Notes